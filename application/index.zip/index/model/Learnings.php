<?php

namespace app\index\model;

use think\Model;

class Learnings extends Model
{
    //
    protected $autoWriteTimestamp = 'datetime';
}
