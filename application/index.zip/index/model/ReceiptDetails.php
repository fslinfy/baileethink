<?php

namespace app\index\model;

use think\Model;

class Receiptdetails extends Model
{
    protected $table='receipt_details';
}
