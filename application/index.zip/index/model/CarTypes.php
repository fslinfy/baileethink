<?php

namespace app\index\model;

use think\Model;


class Cartypes extends Model
{
    protected $table='car_types';
    protected $autoWriteTimestamp = 'datetime';

}
