<?php

namespace app\index\model;

use think\Model;

class Settings extends Model
{
    //
    // protected $autoWriteTimestamp = 'datetime';
}
